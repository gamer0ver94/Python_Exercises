def greetings(name: str) -> str:
    """Wellcome someone passed as parametre.
    Args:
        name(str):  Name of the person to great.
    Returns:
        Return a greeting (str)to a person."""
    return f"Hello {name} this is my first packages ever created by me."
